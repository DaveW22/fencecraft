# Image and identity notes

The logo is an original editable SVG fence-and-leaf mark, drawn directly as vector artwork. It is a design concept; it has not undergone trademark clearance.

The two garden images were made using the built-in image generation tool. They are illustrative visual material, not FenceCraft project evidence. Optimised copies are saved in `dist/assets/` as garden-{640,1200,1800}.webp and patio-{640,1200,1800}.webp. Responsive resizing and WebP compression were applied after generation. Replace these with authorised original project photographs before public launch.

## Garden prompt

Use case: photorealistic-natural. Asset type: landscape website concept hero photograph, wide 3:2 composition. A beautiful achievable modest British suburban back garden, newly fitted natural oak-brown vertical featheredge timber fence along the rear and right boundary, neat green lawn, pale sandstone patio in foreground with one simple wooden garden chair, lush perennial planting beds with lavender and ornamental grasses, mature trees beyond, subtle brick house edge on left. Premium editorial garden photography, soft late afternoon British summer light, natural realistic materials, eye-level view, carefully composed and calm, greens and honey timber tones. No people, no text, no logos, no watermark, no collage. This is illustrative concept imagery, not evidence of actual contractor work.

## Patio prompt

Use case: photorealistic-natural. Asset type: wide landscape website concept service photograph. Editorial architectural photograph of an achievable contemporary British back garden with light grey sandstone paving in the foreground, two shallow broad stone steps, a neat low raised bed with ornamental grasses and lavender, a small warm brown composite deck terrace on right, natural timber horizontal slatted fencing at rear, subtle brick house edge, lush mature planting. No people, no words, no logos, no watermark. Natural overcast daylight with warm highlights. High material realism, tidy precise craftsmanship, eye-level wide 3:2 scene. Illustrative garden design concept, not evidence of actual contractor work.
