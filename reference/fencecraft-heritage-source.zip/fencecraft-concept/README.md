# FenceCraft website design concept

A 21-page, responsive Heritage Craft design proposal. This does not modify fence-craft.co.uk.

## View

Serve `dist/` with any static HTTP server. For example, from this folder:

    python3 -m http.server 8765 --directory dist

Then open http://localhost:8765. Root-relative URLs require a server; opening the HTML directly as a file will not preserve navigation.

## Included

Homepage, services hub, fencing, landscaping, composite decking, patio paving, About, gallery, illustrative project story, areas covered, Contact, quote form, privacy placeholder and interactive design/SEO guide. The guide includes appearance examples, CTA suggestions and a 90-day launch plan.

The fence-and-leaf logo is editable SVG. Three AI-generated garden and park images are provided in three responsive WebP sizes. These are illustrative; replace them with genuine approved work before launch. No fabricated testimonials or ratings are included.

## Preview behaviour

The form validates fields locally and displays a preview confirmation. It sends and stores nothing. Phone and email links use the business's existing public contact details. No analytics or external fonts are added. Pages carry `noindex,follow`; robots.txt allows crawlers to read this directive. No production sitemap is served in preview mode.

## Regenerate

    python3 build.py

The generator uses build.py together with heritage.py. It runs using the standard Python library and does not need an installation step. Image assets already exist. It overwrites generated HTML, CSS and JavaScript; edit build.py if regenerating.

Production preparation is deliberately gated:

    python3 build.py --production --content-approved

Only use this after replacing placeholders, verifying business claims, connecting and testing the form, completing privacy information and removing the design-review UI. This prepares canonical URLs for https://www.fence-craft.co.uk, a sitemap and Organization/Service/BreadcrumbList JSON-LD. It does not deploy the real domain. Confirm all markup and page content before deployment. No address, rating or opening hours are invented; LocalBusiness rich-result eligibility requires additional verified information.

Keep current URL paths where practical and configure actual server-side redirects for /home, removed URLs and trailing-slash variants. A sitemap or HTML link is not a redirect. The included 404.html must be configured by the production host to return an actual HTTP 404.

## Verification performed

Checked internal link and asset destinations, one H1 per page, unique IDs, metadata and image attributes. Browser checks covered desktop/mobile homepage, mobile menu, fencing page, form demonstration, FAQs and design comparison. This is not a completed WCAG conformance or performance audit.

## Heritage Craft version

This version adds home and park customer routes, a glass fencing page, timber and composite decking, park maintenance, static-caravan painting, footing works and a text-only Wyldecrest client-history page. The relationship wording is based on the user’s supplied history: more than 20 years of work at parks in Wrexham and Flintshire. No third-party logo, endorsement, named commission or review has been invented.

The project-type field is preselected for park enquiries. Email is required; telephone is optional. The preview still does not send or store entries.
